﻿using System;

public delegate double Fun(double x, double a);

class Program
{

    public static void Table(Fun F, double x, double a, double b)
    {
        Console.WriteLine("----- X ----- Y -----");
        while (x <= b)
        {
            Console.WriteLine("| {0,8:0.000} | {1,8:0.000} |", x, F(x, a));
            x += 1;
        }
        Console.WriteLine("---------------------");
    }

    // функция a*x^2
    public static double MyFunc1(double x, double a)
    {
        return a * x * x;
    }

    // функция a*sin(x)
    public static double MyFunc2(double x, double a)
    {
        return a * Math.Sin(x);
    }

    static void Main()
    {
        /*
         * Алексей Мамизеров
         * 
         * 1.	Изменить программу вывода таблицы функции так, чтобы можно было передавать функции типа double (double, double).
         *      Продемонстрировать работу на функции с функцией a*x^2 и функцией a*sin(x).
        */


        // Создаем новый делегат и передаем ссылку на него в метод Table
        Console.WriteLine("1. Таблица функции a*x^2:");
        Table(new Fun(MyFunc1), -2, 4, 2);

        Console.WriteLine("\n\n2. Таблица функции a*sin(x):");
        Table(new Fun(MyFunc2), -2, 5, 2);


        Console.ReadLine();
    }
}
