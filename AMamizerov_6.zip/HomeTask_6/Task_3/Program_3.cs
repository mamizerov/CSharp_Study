﻿using System;
using System.Collections;
using System.IO;

namespace Task_3
{
    class Program
    {
        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 3.	Переделать программу Пример использования коллекций для решения следующих задач:
                    а) Подсчитать количество студентов учащихся на 5 и 6 курсах;
                    б) подсчитать сколько студентов в возрасте от 18 до 20 лет на каком курсе учатся (*частотный массив);
                    в) отсортировать список по возрасту студента;
                    г) *отсортировать список по курсу и возрасту студента;
                    д) разработать единый метод подсчета количества студентов по различным параметрам
                       выбора с помощью делегата и методов предикатов.
            */

            int Count56 = 0;
            int Count1820 = 0;
            // Создадим необобщенный список
            ArrayList list = new ArrayList();
            // Запомним время в начале обработки данных
            DateTime dt = DateTime.Now;
            StreamReader sr = new StreamReader("students.csv");
            while (!sr.EndOfStream)
            {
                try
                {
                    string[] s = sr.ReadLine().Split(';');
                    // А)
                    if (int.Parse(s[6]) == 5 || int.Parse(s[6]) == 6) Count56++;
                    // В)
                    if (int.Parse(s[5]) > 17 && int.Parse(s[5]) < 21) Count1820++;
                    list.Add(s[5] + " лет. " + s[0].Substring(1) + " " + s[1]);

                }
                catch
                {
                }
            }
            sr.Close();

            Console.WriteLine($"А) Количество студентов на 5-6 курсах: {Count56}");
            Console.WriteLine($"\nБ) Количество студентов, в возрасте от 18 до 20 лет: {Count1820}");

            // B)

            Console.WriteLine("В) Список отсортирован по возрасту:");
            list.Sort();
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            Pause();
        }
    }
}
