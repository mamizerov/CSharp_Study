﻿using System;
using System.IO;
namespace DoubleBinary
{
    public delegate double Func(double ar);

    class Program
    {
        public static double F(double x)
        {
            return x * x - 50 * x + 10;
        }

        public static double F1(double x)
        {
            return x * x * x + 45;
        }

        public static double F2(double x)
        {
            return x - 5;
        }

        public static double F3(double x)
        {
            return x * x - 10;
        }

        public static void SaveFunc(string fileName, double a, double b, double h)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            Func function;

            function = F;

            double x = a;
            while (x <= b)
            {
                bw.Write(function(x));
                x += h;
            }
            bw.Close();
            fs.Close();
        }

        // функция сохранения для пункта А)
        public static void ASaveFunc(string fileName, int num, double a, double b, double h)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            
            var funcs = new Func[] { F1, F2, F3 };

            double x = a;
            while (x <= b)
            {
                switch (num)
                {
                    case 1: bw.Write(funcs[0](x)); break;
                    case 2: bw.Write(funcs[1](x)); break;
                    default: bw.Write(funcs[2](x)); break;
                }
                
                x += h;
            }
            bw.Close();
            fs.Close();
        }

        public static double Load(string fileName)
        {
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader bw = new BinaryReader(fs);
            double min = double.MaxValue;
            double d;
            for (int i = 0; i < fs.Length / sizeof(double); i++)
            {
                // Считываем значение и переходим к следующему
                d = bw.ReadDouble();
                if (d < min) min = d;
            }
            bw.Close();
            fs.Close();
            return min;
        }

        // B) Load возвращает массив считанных значений
        
        public static double[] BLoad(string fileName, out double minFunc)
        {
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader bw = new BinaryReader(fs);

            double[] AllElements = new double[fs.Length / sizeof(double)];
            double min = double.MaxValue;

            double d;
            for (int i = 0; i < fs.Length / sizeof(double); i++)
            {
                // Считываем значение и переходим к следующему
                d = bw.ReadDouble();

                // записываем значение в наш массив
                AllElements[i] = d;

                if (d < min) min = d;
            }
            bw.Close();
            fs.Close();

            minFunc = min;
            
            return AllElements;
        }

        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 2.	Модифицировать программу нахождения минимума функции так, чтобы можно было передавать функцию в виде делегата. Сделано - делегат Func
             * 
                    а) Сделать меню с различными функциями и представить пользователю выбор, для какой функции и на каком отрезке находить минимум.
                        Использовать массив (или список) делегатов, в котором хранятся различные функции.

                    б) *Переделать функцию Load, чтобы она возвращала массив считанных значений. 
                        Пусть она возвращает минимум через параметр (с использованием модификатора out). 
            */

            SaveFunc("data.txt", -100, 100, 2);
            Console.WriteLine($"Функция передается в виде делегата. Минимум функции: {Load("data.txt")}");

            // А)

            // будет предоставлено на выбор три функции: 1. x * x * x + 45  2. x - 5  3. x * x - 10 
            // для сохранения будет создан новый метод ASaveFunc в котором доп параметром будет номер функции

            string[] FunctionArray = { "1. x * x * x + 45", "2. x - 5", "3. x * x - 10" };
            Console.WriteLine("\nA) Выберите номер функции:");
            foreach (var item in FunctionArray)
            {
                Console.WriteLine(item);
            }
            bool flag = false;
            int num = 0;
            do
            {
                try
                {
                    num = int.Parse(Console.ReadLine());
                    if (num > 0 && num < 4)
                        flag = true;
                }
                catch
                {
                    flag = false;
                }
                
            } while (!flag);

            Console.Write("Введите начало отрезка А: ");
            double startA = double.Parse(Console.ReadLine());

            Console.Write("Введите конец отрезка B: ");
            double startB = double.Parse(Console.ReadLine());

            Console.Write("Введите шаг: ");
            double step = double.Parse(Console.ReadLine());

            ASaveFunc("data.txt", num, startA, startB, step);
            Console.WriteLine($"А) Минимум функции: {Load("data.txt")}");

            // B)
            double min;
            double[] funcData = BLoad("Data.txt", out min);

            Console.WriteLine($"\n\nB) Минимальное значение функции (функция по начальным условиям, не из п.А) = {min}");
            Console.WriteLine("Все значения функции:");
            foreach (var item in funcData)
            {
                Console.WriteLine(item);
            }

            Pause();
        }
    }
}
