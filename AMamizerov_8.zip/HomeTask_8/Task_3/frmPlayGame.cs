﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

namespace Task_3
{
    public partial class frmPlayGame : Form
    {
        [Serializable]
        public class Question
        {
            public string text;
            public bool trueFalse;

            public Question()
            {
            }

            public Question(string text, bool trueFalse)
            {
                this.text = text;
                this.trueFalse = trueFalse;
            }
        }
                     
        public frmPlayGame()
        {
            InitializeComponent();
        }

        public List<Question> list;
        public int IndexQuestion = 0;
        public int Success = 0;

        private void btLoadDataFromFile_Click(object sender, EventArgs e)
        {
            string fileName;

            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Question>));
                    Stream fStream = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
                    list = (List<Question>)xmlFormat.Deserialize(fStream);
                    fStream.Close();

                    if (list.Count != null)
                    {
                        txtQuestion.Text = list[0].text;
                        btBelive.Enabled = true;
                        btNoBelive.Enabled = true;
                        btLoadDataFromFile.Enabled = false;
                        lblCountQuestions.Text = $"В игре {list.Count} вопросов.";
                        lblCountQuestions.Visible = true;
                        lblOstalos.Text = $"Осталось: {list.Count}";
                        lblOstalos.Visible = true;
                    }
                }
                // Перехват ошибки на не существующий файл
                catch (FileNotFoundException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                // ошибка при загрузке файла
                catch (FileLoadException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btBelive_Click(object sender, EventArgs e)
        {
            if(list[IndexQuestion].trueFalse)
            {
                MessageBox.Show("Верно!", "Поздравляю!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                Success++;
            }
            
            IndexQuestion++;

            if (IndexQuestion == list.Count)
            {
                btBelive.Enabled = false;
                btNoBelive.Enabled = false;
                btLoadDataFromFile.Enabled = true;
                lblCountQuestions.Visible = false;
                lblOstalos.Visible = false;
                txtQuestion.Text = String.Empty;
                MessageBox.Show($"Из {list.Count} вопросов Вы угадали на {Success} !!!");
                IndexQuestion = 0;
                Success = 0;
            }
            else
            {
                txtQuestion.Text = list[IndexQuestion].text;
                lblOstalos.Text = $"Осталось: {list.Count - IndexQuestion}";
            }
        }

        private void btNoBelive_Click(object sender, EventArgs e)
        {
            if (!list[IndexQuestion].trueFalse)
            {
                MessageBox.Show("Верно!", "Поздравляю!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                Success++;
            }

            IndexQuestion++;

            if (IndexQuestion == list.Count)
            {
                btBelive.Enabled = false;
                btNoBelive.Enabled = false;
                btLoadDataFromFile.Enabled = true;
                lblCountQuestions.Visible = false;
                lblOstalos.Visible = false;
                txtQuestion.Text = String.Empty;
                MessageBox.Show($"Из {list.Count} вопросов Вы угадали на {Success} !!!");
                IndexQuestion = 0;
                Success = 0;
            }
            else
            {
                txtQuestion.Text = list[IndexQuestion].text;
                lblOstalos.Text = $"Осталось: {list.Count - IndexQuestion}";
            }
        }
    }
}
