﻿namespace Task_3
{
    partial class frmPlayGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btLoadDataFromFile = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtQuestion = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btNoBelive = new System.Windows.Forms.Button();
            this.btBelive = new System.Windows.Forms.Button();
            this.lblCountQuestions = new System.Windows.Forms.Label();
            this.lblOstalos = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btLoadDataFromFile);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(518, 51);
            this.panel1.TabIndex = 0;
            // 
            // btLoadDataFromFile
            // 
            this.btLoadDataFromFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btLoadDataFromFile.Location = new System.Drawing.Point(86, 9);
            this.btLoadDataFromFile.Name = "btLoadDataFromFile";
            this.btLoadDataFromFile.Size = new System.Drawing.Size(341, 33);
            this.btLoadDataFromFile.TabIndex = 0;
            this.btLoadDataFromFile.Text = "Загрузить вопросы из файла";
            this.btLoadDataFromFile.UseVisualStyleBackColor = true;
            this.btLoadDataFromFile.Click += new System.EventHandler(this.btLoadDataFromFile_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtQuestion);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(518, 273);
            this.panel2.TabIndex = 1;
            // 
            // txtQuestion
            // 
            this.txtQuestion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtQuestion.Location = new System.Drawing.Point(0, 0);
            this.txtQuestion.Multiline = true;
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.Size = new System.Drawing.Size(518, 273);
            this.txtQuestion.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblOstalos);
            this.panel3.Controls.Add(this.lblCountQuestions);
            this.panel3.Controls.Add(this.btNoBelive);
            this.panel3.Controls.Add(this.btBelive);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 252);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(518, 72);
            this.panel3.TabIndex = 2;
            // 
            // btNoBelive
            // 
            this.btNoBelive.Enabled = false;
            this.btNoBelive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btNoBelive.Location = new System.Drawing.Point(334, 15);
            this.btNoBelive.Name = "btNoBelive";
            this.btNoBelive.Size = new System.Drawing.Size(145, 40);
            this.btNoBelive.TabIndex = 1;
            this.btNoBelive.Text = "НЕ ВЕРЮ";
            this.btNoBelive.UseVisualStyleBackColor = true;
            this.btNoBelive.Click += new System.EventHandler(this.btNoBelive_Click);
            // 
            // btBelive
            // 
            this.btBelive.Enabled = false;
            this.btBelive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btBelive.Location = new System.Drawing.Point(37, 15);
            this.btBelive.Name = "btBelive";
            this.btBelive.Size = new System.Drawing.Size(145, 40);
            this.btBelive.TabIndex = 0;
            this.btBelive.Text = "ВЕРЮ";
            this.btBelive.UseVisualStyleBackColor = true;
            this.btBelive.Click += new System.EventHandler(this.btBelive_Click);
            // 
            // lblCountQuestions
            // 
            this.lblCountQuestions.AutoSize = true;
            this.lblCountQuestions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCountQuestions.Location = new System.Drawing.Point(196, 15);
            this.lblCountQuestions.Name = "lblCountQuestions";
            this.lblCountQuestions.Size = new System.Drawing.Size(46, 17);
            this.lblCountQuestions.TabIndex = 2;
            this.lblCountQuestions.Text = "label1";
            this.lblCountQuestions.Visible = false;
            // 
            // lblOstalos
            // 
            this.lblOstalos.AutoSize = true;
            this.lblOstalos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOstalos.Location = new System.Drawing.Point(196, 36);
            this.lblOstalos.Name = "lblOstalos";
            this.lblOstalos.Size = new System.Drawing.Size(46, 17);
            this.lblOstalos.TabIndex = 3;
            this.lblOstalos.Text = "label1";
            this.lblOstalos.Visible = false;
            // 
            // frmPlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 324);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPlayGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Игра: Верю - Не верю";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btLoadDataFromFile;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtQuestion;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btNoBelive;
        private System.Windows.Forms.Button btBelive;
        private System.Windows.Forms.Label lblCountQuestions;
        private System.Windows.Forms.Label lblOstalos;
    }
}