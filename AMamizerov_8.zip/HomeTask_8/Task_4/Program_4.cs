﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Task_4
{
    [Serializable]
    public class Student
    {
        public string firstName;
        public string secondName;
        public string Univercity;
        public string Faculty;
        public string Department;
        public string Age;
        public string Course;
        public string Group;
        public string City;

        public Student()
        {
        }

        public Student(string firstName, string secondName, string Univercity, string Faculty, string Department, string Age, string Course, string Group, string City)
        {
            this.firstName = firstName;
            this.secondName = secondName;
            this.Univercity = Univercity;
            this.Faculty = Faculty;
            this.Department = Department;
            this.Age = Age;
            this.Course = Course;
            this.Group = Group;
            this.City = City;
        }
    }

    class Program
    {


        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        public List<Student> list;

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров 
             * 
             * 5.	**Написать программу-преобразователь из CSV в XML-файл с информацией о студентах (6 урок).
             * 
             *  Сформированный файл student.xml будет находится в каталоге, где лежит exe-файл
            */

            List<Student> list = new List<Student>();
            StreamReader sr = new StreamReader("students.csv");
            while (!sr.EndOfStream)
            {
                try
                {
                    string[] s = sr.ReadLine().Split(';');
                    list.Add(new Student(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8]));
                }
                catch
                {
                }
            }
            sr.Close();

            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Student>));
            Stream fStream = new FileStream("student.xml", FileMode.Create, FileAccess.Write);
            xmlFormat.Serialize(fStream, list);
            fStream.Close();

            Pause();
        }
    }
}
