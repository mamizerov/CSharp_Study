﻿namespace Task_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numupdownNumbers = new System.Windows.Forms.NumericUpDown();
            this.txtNumber = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numupdownNumbers)).BeginInit();
            this.SuspendLayout();
            // 
            // numupdownNumbers
            // 
            this.numupdownNumbers.Location = new System.Drawing.Point(45, 51);
            this.numupdownNumbers.Name = "numupdownNumbers";
            this.numupdownNumbers.Size = new System.Drawing.Size(120, 20);
            this.numupdownNumbers.TabIndex = 0;
            this.numupdownNumbers.ValueChanged += new System.EventHandler(this.numupdownNumbers_ValueChanged);
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(196, 51);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(100, 20);
            this.txtNumber.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 129);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.numupdownNumbers);
            this.Name = "Form1";
            this.Text = "Задача 2";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numupdownNumbers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numupdownNumbers;
        private System.Windows.Forms.TextBox txtNumber;
    }
}

