﻿using System;
using System.Reflection;

namespace Task_1
{
    class Program
    {
        static PropertyInfo GetPropertyInfo(object obj, string str)
        {
            return obj.GetType().GetProperty(str);
        }


        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 1.	С помощью рефлексии выведите все свойства структуры DateTime
            */

                Type t = typeof(DateTime);
                foreach (var prop in t.GetProperties())
                    Console.WriteLine(prop.Name);

                Console.ReadKey();

        }
    }
}
