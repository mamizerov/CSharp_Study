﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Task_2
{
    class Program
    {
        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        // Метод для подсчета количество пар, где только один элемент делится на 3
        private static int CountPar(int[] array)
        {
            int CountPar = 0;

            for (int i = 0; i < array.Length - 1; i = i + 2)
            {
                if ((array[i] % 3 == 0 && array[i + 1] % 3 != 0) || (array[i] % 3 != 0 && array[i + 1] % 3 == 0))
                {
                    CountPar++;
                    Console.Write($"\nИндекс первого члена пары {i}, индекс второго члена пары {i + 1}");
                }

            }

            return CountPar;
        }

        // Метод для считывания элементов из файла Array.txt в массив. Разделитель элементов - два пробела. Возвращает массив
        private static int[] LoadArrayFromFile(string Path)
        {
            try
            {
                StreamReader srFile = new StreamReader(Path);
                int[] array = new int[20];

                char pattern = ' ';
                var temp = srFile.ReadLine().Split(pattern);

                for (int i = 0; i < temp.Length; i++)
                {
                    array[i] = int.Parse(temp[i]);
                }

                return array;
            }
            catch (Exception)
            {

                Console.WriteLine("Ошибка при загрузке или считывании файла с данными.");
                return null;
            }

        }


        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 2.	Реализуйте задачу 1 в виде статического класса StaticClass;
                    а) Класс должен содержать статический метод, который принимает на вход массив и решает задачу

                    б) *Добавьте статический метод для считывания массива из текстового файла. Метод должен возвращать массив целых чисел;

                    в)**Добавьте обработку ситуации отсутствия файла на диске.
            */

            int[] arrayNumbers = new int[20];
            Random rand = new Random();

            // А)

            Console.WriteLine("A)");

            for (int i = 0; i < arrayNumbers.Length; i++)
            {
                arrayNumbers[i] = rand.Next(-10000, 10000);
            }

            for (int i = 0; i < arrayNumbers.Length; i++)
            {
                Console.Write(arrayNumbers[i] + "  ");
            }

            Console.WriteLine($"\n\nВ данном массиве {CountPar(arrayNumbers)} пар делится на 3.");

            // Б)

            Console.WriteLine("\nБ)");

            string PathFile = "Array.txt";
            arrayNumbers = LoadArrayFromFile(PathFile);

            if(arrayNumbers != null)
            {
                for (int i = 0; i < arrayNumbers.Length; i++)
                {
                    Console.Write(arrayNumbers[i] + "  ");
                }

                Console.WriteLine($"\n\nВ данном массиве {CountPar(arrayNumbers)} пар делится на 3.");
            }
            else
                Console.WriteLine($"\n\nПустой массив.");


            // В)

            // В методе LoadArrayFromFile добавлен TRY для перехвата ошибки считывания файла.
            // Если переименуете файл HomeTask_4\Task_1\bin\Debug\Array.txt то будет предупреждение о неудаче считывания данных!!!


            Pause();
        }


    }
}
