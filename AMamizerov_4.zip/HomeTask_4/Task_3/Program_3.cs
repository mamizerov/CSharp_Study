﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3
{
    class FillArray
    {
        int[] array;

        // Метод заполнения массива. Параметры: длина массива, начальное значение, шаг увеличения элемента массива
        public FillArray(int ArrayLength, int StartNumber, int Step)
        {
            array = new int[ArrayLength];

            for (int i = 0; i < array.Length; i++)
            {
                if (i == 0)
                    array[i] = StartNumber;
                else
                    array[i] = array[i - 1] + Step;
            }
        }

        // Свойство подсчета суммы элементов массива
        public int Summ
        {
            get
            {
                int summ = 0;
                for (int i = 0; i < array.Length; i++)
                    summ += array[i];

                return summ;
            }
        }

        //  метод Inverse, возвращающий новый массив с измененными знаками у всех элементов массива(старый массив, остается без изменений)
        public int[] Inverse()
        {
            int[] inv = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
                inv[i] = -1 * array[i];

            return inv;
        }

        //  метод Multi, умножающий каждый элемент массива на определённое число
        public int[] Multi(int factor)
        {
            int[] inv = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
                inv[i] = factor * array[i];

            return inv;
        }

        // свойство MaxCount, возвращающее количество максимальных элементов, но по условию задачи максимальных элементов всегда будет только 1, так как вводим шаг увеличения массива
        public int MaxCount
        {
            get
            {
                int MaxCnt = 0;
                int MaxElement = array[0];
                // находим макс элемент
                for (int i = 1; i < array.Length; i++)
                    if (MaxElement < array[i])
                        MaxElement = array[i];
                // подсчитываем количество элементов равных максимальному
                for (int i = 0; i < array.Length; i++)
                    if (array[i] == MaxElement)
                        MaxCnt++;

                return MaxCnt;
            }
        }

        // Вывод массива
        public override string ToString()
        {
            string s = "";
            foreach (int v in array)
                s = s + v + " ";
            return s;
        }

    }

    class Program
    {


        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 3.	а) Дописать класс для работы с одномерным массивом. Реализовать конструктор, создающий массив определенного размера и заполняющий массив числами
             * от начального значения с заданным шагом. Создать свойство Sum, которое возвращает сумму элементов массива, метод Inverse, возвращающий новый массив
             * с измененными знаками у всех элементов массива (старый массив, остается без изменений),  метод Multi, умножающий каждый элемент массива на определённое число,
             * свойство MaxCount, возвращающее количество максимальных элементов. 
            */

            // Ввод параметров массива
            Console.Write("Введите размер массива: ");
            int ArrayLength = int.Parse(Console.ReadLine());

            Console.Write("Введите начальное значение массива: ");
            int StartNumber = int.Parse(Console.ReadLine());

            Console.Write("Введите шаг значений: ");
            int Step = int.Parse(Console.ReadLine());

            // Формирование и заполнение массива
            FillArray array = new FillArray(ArrayLength, StartNumber, Step);
                     
            Console.Write($"\nСформирован массив: {array}");

            // Свойство Summ
            Console.WriteLine($"\n\nСумма элементов массива: {array.Summ}");

            // Инверсия
            int[] inv = array.Inverse();
            Console.WriteLine($"\nИнверсия массива:");
            for (int i = 0; i < ArrayLength; i++)
            {
                Console.Write($"{inv[i]}  ");
            }

            // Multi - умножение элементов массива
            Console.Write("\n\nВведите число, на которое надо умножить каждый элемент массива: ");
            int factor = int.Parse(Console.ReadLine());

            int[] multi = array.Multi(factor);
            Console.WriteLine($"Умножение элементов массива:");
            for (int i = 0; i < ArrayLength; i++)
            {
                Console.Write($"{multi[i]}  ");
            }

            // MaxCount Количество максимальных элементов
            Console.WriteLine($"\n\nКоличество максимальных элементов массива: {array.MaxCount}");

            Pause();
        }
    }
}
