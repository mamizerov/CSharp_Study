﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1
{
    class Program
    {
        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 1.	Дан  целочисленный  массив  из 20 элементов.  Элементы  массива  могут принимать  целые  значения  от –10 000 до 10 000 включительно.
             * Заполнить случайными числами.  Написать программу, позволяющую найти и вывести количество пар элементов массива, в которых только одно число делится на 3.
             * В данной задаче под парой подразумевается два подряд идущих элемента массива. Например, для массива из пяти элементов: 6; 2; 9; –3; 6 ответ — 2. 

            */
            int[] arrayNumbers = new int[20];
            Random rand = new Random();
            int CountPar = 0;

            for (int i = 0; i < arrayNumbers.Length; i++)
            {
                arrayNumbers[i] = rand.Next(-10000, 10000);
            }

            for (int i = 0; i < arrayNumbers.Length; i++)
            {
                Console.Write(arrayNumbers[i] + "  ");
            }

            for (int i = 0; i < arrayNumbers.Length - 1; i = i + 2)
            {
                if ((arrayNumbers[i] % 3 == 0 && arrayNumbers[i + 1] % 3 != 0) || (arrayNumbers[i] % 3 != 0 && arrayNumbers[i + 1] % 3 == 0))
                {
                    CountPar++;
                    Console.Write($"\nИндекс первого члена пары {i}, индекс второго члена пары {i + 1}");
                }
                    
            }

            Console.WriteLine($"\n\nВ данном массиве {CountPar} пар делится на 3.");

            Pause();
        }
    }
}
