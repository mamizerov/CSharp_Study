﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Task_1
{
    class Program
    {
        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 1. Создать программу, которая будет проверять корректность ввода логина. Корректным логином будет строка от 2 до 10 символов, 
             * содержащая только буквы латинского алфавита или цифры, при этом цифра не может быть первой:

                    а) без использования регулярных выражений;
                    б) с использованием регулярных выражений.

            */

            // A)

            Console.WriteLine("A)");
            Boolean CorrectLogin = false;
            do
            {
                Console.Write("Введите логин: ");
                StringBuilder Login =new StringBuilder(Console.ReadLine());

                if (Login.Length >= 2 && Login.Length <= 10)
                {
                    if (!Char.IsDigit(Login[0]))
                    {
                        for (int i = 0; i < Login.Length; i++)
                        {
                            if ( ((int)Login[i] > 64 && (int)Login[i] < 91) || ((int)Login[i] > 96 && (int)Login[i] < 123) || ((int)Login[i] > 47 && (int)Login[i] < 58))
                                CorrectLogin = true;
                            else
                            {
                                Console.WriteLine("Логин должен содержать только латинские буквы или цифры.");
                                CorrectLogin = false;
                                break;
                            }
                        }
                    }
                    else
                        Console.WriteLine("Цифра не может быть первой.");
                }
                else
                    Console.WriteLine("Длина логина должна быть от 2 до 10 символов.");
                

            } while (!CorrectLogin);

            if(CorrectLogin) Console.WriteLine("\nВы ввели верный логин!");

            // Б)

            Console.WriteLine("\nБ) REGEX");
            CorrectLogin = false;

            do
            {

                Console.Write("Введите логин: ");
                StringBuilder Login = new StringBuilder(Console.ReadLine());

                Match m = Regex.Match(Login.ToString(), @"[а-яА-Я]");

                if (Login.Length >= 2 && Login.Length <= 10)
                {
                    if (!Char.IsDigit(Login[0]))
                    {
                        if(m.Length == 0)
                            CorrectLogin = true;
                        else
                        {
                            Console.WriteLine("Логин должен содержать только латинские буквы или цифры.");
                            CorrectLogin = false;
                        }
                    }
                    else
                        Console.WriteLine("Цифра не может быть первой.");
                }
                else
                    Console.WriteLine("Длина логина должна быть от 2 до 10 символов.");


            } while (!CorrectLogin);

            if (CorrectLogin) Console.WriteLine("\nВы ввели верный логин!");

            Pause();
        }
    }
}
