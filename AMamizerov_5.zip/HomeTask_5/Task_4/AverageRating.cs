﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Task_4
{
    class AverageRating
    {
        // Метод для загрузки сообщения из файла , возвращает 2-мерный массив строк: ФИО и средняя оценка
        private string[,] LoadTextFromFile(string Path)
        {
            StreamReader srFile = new StreamReader(Path);
            // получаем количество студентов
            int N = Int32.Parse(srFile.ReadLine());
           
            string[,] ListStudents = new string[N, 2];
            string[] tmp = new string[5];

            // считываем каждую строку из файла. 
            for (int i = 0; i < N; i++)
            {
                tmp = srFile.ReadLine().Split(' ');
                ListStudents[i, 0] = tmp[0] + " " + tmp[1];
                ListStudents[i, 1] = Convert.ToDouble((Convert.ToDouble(tmp[2]) + Convert.ToDouble(tmp[3]) + Convert.ToDouble(tmp[4])) / 3).ToString("##.##");
            }

            srFile.Close();

            return ListStudents;
        }




        // метод определения худших студентов по средней оценке
        public void GetRating(string Path)
        {
            string[,] ListStudents = LoadTextFromFile(Path);

            // определяем худшую среднюю оценку
            double minRating = 5;

            for (int i = 0; i < ListStudents.GetLength(0); i++)
            {
                if (Convert.ToDouble(ListStudents[i, 1]) <= minRating)
                    minRating = Convert.ToDouble(ListStudents[i, 1]);
            }
            Console.WriteLine($"Минимальная средняя оценка: {minRating}");

            // выводим ФИО с минимальной средней оценкой
            for (int i = 0; i < ListStudents.GetLength(0); i++)
            {
                if (Convert.ToDouble(ListStudents[i, 1]) == minRating)
                    Console.WriteLine($"{ListStudents[i, 0]} - {minRating}");
            }
        }
    }
}
