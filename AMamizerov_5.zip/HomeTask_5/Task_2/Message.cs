﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Task_2
{
    // Класс работы с сообщением

    class Message
    {
        // Метод для загрузки сообщения из файла
        public string LoadTextFromFile(string Path)
        {
            StreamReader srFile = new StreamReader(Path);
            string TextFromFile = srFile.ReadToEnd(); // .ReadLine();
            srFile.Close();

            return TextFromFile;

        }

        // Метод возвращает массив слов из сообщения, длина которых менее N символов
        public string[] GetWordsLessN(string InputText, int N)
        {
            // разбиваем текст на массив - разделитель пробел
            string[] Words = InputText.Split(' ');

            // объявляем массив для нужных слов < N
            string[] NewArray = new string[0];

            int Count = 0;

            // отбираем слова, длиною меньше N символов
            for (int i = 0; i < Words.Length; i++)
            {
                if (Words[i].Length < N && !String.IsNullOrWhiteSpace(Words[i]))
                {
                    Array.Resize(ref NewArray, NewArray.Length + 1);
                    NewArray[Count] = Words[i];
                    Count++;
                }
            }

            return NewArray;
        }

        // Удалить из сообщения все слова, которые заканчиваются на заданный символ. Если вводите букву "а", то "а)" не удалится, так как заканчиватся на ")"
        public string GetNewMessage(string InputText, string EndLetter)
        {
            // временная переменная для сообщения - будем её обрабатывать
            string tmp = InputText;

            // удаляем знаки препинания
            for (int i = 0; i < tmp.Length; i++)
            {
                if (char.IsPunctuation(tmp[i]))
                    tmp = tmp.Remove(i, 1);
            }
            
            // разбиваем сообщение на массив слов
            string[] Words = tmp.Split(' ');

            // удаляем из сообщения слова, заканчивающиеся на нашу букву
            foreach (string item in Words)
            {
                if(!String.IsNullOrWhiteSpace(item))
                    if (item.Substring(item.Length - 1).Equals(EndLetter))
                    {
                        InputText = InputText.Replace(item, String.Empty);
                    }
            }

            return InputText;
        }

        // поиск максимального слова в сообщении
        public string MaxWord(string InputText)
        {
            string tmp = InputText;

            // убираем скрытые символы
            tmp = tmp.Replace(Environment.NewLine, " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\\r", " ").Replace("\\n", " ");

            // разбиваем сообщение на массив слов
            string[] Words = tmp.Split(' ');

            if (Words.Length > 0)
            {
                string word = Words[0];
                for (int i = 1; i < Words.Length; i++)
                {
                    if(word.Length < Words[i].Length)
                        word = Words[i];
                }

                return word;
            }
            else
                return null;
        }

        // сформировать строку с помощью StringBuilder из самых длинных слов сообщения.
        public string GetStringFromMaxWords(string InputText)
        {
            string tmp = InputText;

            // убираем скрытые символы
            tmp = tmp.Replace(Environment.NewLine, " ").Replace("\r\n", " ").Replace("\r", " ").Replace("\n", " ").Replace("\\r", " ").Replace("\\n", " ");

            // разбиваем сообщение на массив слов
            string[] Words = tmp.Split(' ');

            if (Words.Length > 0)
            {
                StringBuilder word = new StringBuilder(Words[0]);
                int len = word.Length;

                // склеиваем строку из максимальных по длине слов
                for (int i = 1; i < Words.Length; i++)
                {
                    if (word.Length < Words[i].Length)
                    {
                        word = new StringBuilder(Words[i]);
                        len = Words[i].Length;
                    }
                    else
                        if (len == Words[i].Length)
                            word.Append(Words[i]);
                }

                return word.ToString();
            }
            else
                return null;
        }

    }
}
