﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2
{


    class Program
    {
        /// <summary>
        /// Остановка экрана
        /// </summary>
        static void Pause()
        {
            Console.Write("\nДля выхода нажмите Enter.");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            /*
             * Алексей Мамизеров
             * 
             * 2. Разработать класс Message, содержащий следующие статические методы для обработки текста:

                    а) Вывести только те слова сообщения, которые содержат не более n букв.
                    б) Удалить из сообщения все слова, которые заканчиваются на заданный символ.
                    в) Найти самое длинное слово сообщения.
                    г) Сформировать строку с помощью StringBuilder из самых длинных слов сообщения.
                    Продемонстрируйте работу программы на текстовом файле с вашей программой.
            */

            // Создан класс Message.cs

            Message msg = new Message();

            string TextFromFile = msg.LoadTextFromFile("Data.txt");

            Console.WriteLine($"Входное сообщение следующее:\n\n{TextFromFile}");

            // A)

            Console.Write("\nА) Вывести только те слова, которые содержат не более N букв. Введите N: ");
            int CountLettersInWord = Int32.Parse(Console.ReadLine());

            string[] Words = msg.GetWordsLessN(TextFromFile, CountLettersInWord);

            if (Words.Length == 0)
                Console.WriteLine($"Нет в тексте слов, длина которых меньше {CountLettersInWord} букв");
            else
                foreach (var word in Words)
                {
                    Console.WriteLine(word);
                }

            // Б)

            Console.Write("\nБ) Удалить из сообщения все слова, которые заканчиваются на: ");
            string EndLette = Console.ReadLine();

            Console.WriteLine($"\n{msg.GetNewMessage(TextFromFile, EndLette)}");

            // В)

            Console.Write($"\n\n\nВ) Самое длинное слово сообщения: {msg.MaxWord(TextFromFile)}\n");

            // Г)

            Console.Write($"\n\n\nГ) Строка из самых длинных слов сообщения: {msg.GetStringFromMaxWords(TextFromFile)}\n");

            Pause();
        }
    }
}
