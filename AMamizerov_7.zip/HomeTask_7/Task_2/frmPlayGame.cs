﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_2
{
    public partial class frmPlayGame : Form
    {
        public int randNumber;
        int CountTry = 0;

        public frmPlayGame()
        {
            InitializeComponent();
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(txtNumber.Text);
                if (num > randNumber)
                {
                    MessageBox.Show("Ваше число больше загаданного.");
                    CountTry++;
                }
                else if (num < randNumber)
                {
                    MessageBox.Show("Ваше число меньше загаданного.");
                    CountTry++;
                }
                else
                {
                    MessageBox.Show($"Вы угадали число {randNumber} за {CountTry} попыток.");
                    btnGuess.Enabled = false;
                    txtNumber.Enabled = false;
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Надо ввести целое число!");
            }
        }
    }
}
