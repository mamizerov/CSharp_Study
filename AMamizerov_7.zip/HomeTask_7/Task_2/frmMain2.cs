﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_2
{
    public partial class frmMain2 : Form
    {
        public int randNumber =0;
        int CountTry = 0;

        public frmMain2()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void frmMain2_Load(object sender, EventArgs e)
        {
            /*
             * Алексей Мамизеров
             * 
             * 2.	Используя Windows Forms, разработать игру «Угадай число».
             *      Компьютер загадывает число от 1 до 100, а человек пытается его угадать за минимальное число попыток. Компьютер говорит, больше или меньше загаданное число введенного.  
                    a) Для ввода данных от человека используется элемент TextBox;
                    б) **Реализовать отдельную форму c TextBox для ввода числа.
            */
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void menuStartPlay_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            randNumber = r.Next(1, 100);
            MessageBox.Show("Компьютер загадал число от 1 до 100! Угадайте его!", "Игра началась", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btnGuess.Enabled = true;
            btnStartPlay.Enabled = true;
            txtNumber.Enabled = true;
            txtNumber.Text = "0";
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(txtNumber.Text);
                if (num > randNumber)
                {
                    MessageBox.Show("Ваше число больше загаданного.");
                    CountTry++;
                }
                else if (num < randNumber)
                {
                    MessageBox.Show("Ваше число меньше загаданного.");
                    CountTry++;
                }
                else
                {
                    MessageBox.Show($"Вы угадали число {randNumber} за {CountTry} попыток.");
                    btnGuess.Enabled = false;
                    btnStartPlay.Enabled = false;
                    txtNumber.Enabled = false;
                }
            }
            catch
            {
                MessageBox.Show("Надо ввести целое число!");
            }
            
        }

        private void btnStartPlay_Click(object sender, EventArgs e)
        {
            frmPlayGame frm2 = new frmPlayGame();
            frm2.randNumber = randNumber;
            frm2.ShowDialog();
        }
    }
}
