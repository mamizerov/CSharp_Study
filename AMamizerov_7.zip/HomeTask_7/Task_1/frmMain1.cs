﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_1
{
    public partial class frmMain1 : Form
    {
        int CountAdd = 0;
        int CountMulti = 0;
        int PlayNumber = 0;
        int CountMove = 0;
        int PreviusNumber = 0;

        public frmMain1()
        {
            /*
             * Алексей Мамизеров
             * 
             * 1.	а) Добавить в программу «Удвоитель» подсчёт количества отданных команд удвоителю.
                    б) Добавить меню и команду «Играть». При нажатии появляется сообщение, какое число должен получить игрок. Игрок должен получить это число за минимальное количество ходов.
                    в) *Добавить кнопку «Отменить», которая отменяет последние ходы. Используйте обобщенный класс Stack.
                    Вся логика игры должна быть реализована в классе с удвоителем.
            */

            InitializeComponent();
            lblNumber.Text = "1";
            btnCancelMove.Enabled = false;

        }

        private void btnCommand1_Click(object sender, EventArgs e)
        {
            PreviusNumber = int.Parse(lblNumber.Text);
            lblNumber.Text = (int.Parse(lblNumber.Text) + 1).ToString();
            CountAdd++;
            lblAdd.Text = (int.Parse(lblAdd.Text) + 1).ToString();
            CountMove++;

            if (PlayNumber != 0)
            {
                btnCancelMove.Enabled = true;
                if (PlayNumber == int.Parse(lblNumber.Text))
                {
                    MessageBox.Show($"Поздравляю, Вы получили число {PlayNumber} за {CountMove} ходов.");
                    lblNumber.Text = "1";
                    lblAdd.Text = "0";
                    lblMulti.Text = "0";
                    PlayNumber = 0;
                    CountMove = 0;
                    btnCancelMove.Enabled = false;
                }
                else if (PlayNumber < int.Parse(lblNumber.Text))
                {
                    MessageBox.Show($"Вы проиграли ! {lblNumber.Text} больше {PlayNumber}");
                    lblNumber.Text = "1";
                    lblAdd.Text = "0";
                    lblMulti.Text = "0";
                    PlayNumber = 0;
                    CountMove = 0;
                    btnCancelMove.Enabled = false;
                }
            }
            
        }

        private void btnCommand2_Click(object sender, EventArgs e)
        {
            PreviusNumber = int.Parse(lblNumber.Text);
            lblNumber.Text = (int.Parse(lblNumber.Text) * 2).ToString();
            CountMulti++;
            lblMulti.Text = (int.Parse(lblMulti.Text) + 1).ToString();
            CountMove++;

            if (PlayNumber != 0)
            {
                btnCancelMove.Enabled = true;
                if (PlayNumber == int.Parse(lblNumber.Text))
                {
                    MessageBox.Show($"Поздравляю, Вы получили число {PlayNumber} за {CountMove} ходов.");
                    lblNumber.Text = "1";
                    lblAdd.Text = "0";
                    lblMulti.Text = "0";
                    PlayNumber = 0;
                    CountMove = 0;
                    btnCancelMove.Enabled = false;
                }
                else if (PlayNumber < int.Parse(lblNumber.Text))
                {
                    MessageBox.Show($"Вы проиграли ! {lblNumber.Text} больше {PlayNumber}");
                    lblNumber.Text = "1";
                    lblAdd.Text = "0";
                    lblMulti.Text = "0";
                    PlayNumber = 0;
                    CountMove = 0;
                    btnCancelMove.Enabled = false;
                }
            }
           
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblNumber.Text = "1";
            lblAdd.Text = "0";
            lblMulti.Text = "0";
            PlayNumber = 0;
            CountMove = 0;
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void menuPlay_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            PlayNumber = r.Next(10, 100);
            lblNumber.Text = "1";
            lblAdd.Text = "0";
            lblAdd.Text = "0";
            lblMulti.Text = "0";
            CountMove = 0;
            MessageBox.Show($"Вы должны получить число {PlayNumber} за минимальное число нажатий '+1' и '*2'.", "Запомните число", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelMove_Click(object sender, EventArgs e)
        {
            if (CountMove > 0)
            {
                lblNumber.Text = PreviusNumber.ToString();
                lblMulti.Text = (int.Parse(lblMulti.Text) - 1).ToString();
                lblAdd.Text = (int.Parse(lblAdd.Text) - 1).ToString();
                CountMove--;
                btnCancelMove.Enabled = false;
            }
            
        }
    }
}
